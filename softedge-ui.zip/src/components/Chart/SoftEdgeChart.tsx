import React from 'react';

export const SoftEdgeChart = () => {
  return <div>📊 SoftEdgeChart Component, hahaha bisa jalan</div>;
};